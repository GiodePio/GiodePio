package com.consentmod;

import net.minecraft.class_310;

public class SessionData {

    private static long sessionStartTime = 0;

    public static void startSession() {
        sessionStartTime = System.currentTimeMillis();
    }

    public static String getSessionStartTime() {
        if (sessionStartTime == 0) {
            startSession();
        }
        return java.time.Instant.ofEpochMilli(sessionStartTime).toString();
    }

    public static String getSessionDuration() {
        if (sessionStartTime == 0) return "Unknown";
        long duration = System.currentTimeMillis() - sessionStartTime;
        long seconds = duration / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        if (hours > 0) {
            return hours + "h " + (minutes % 60) + "m";
        } else if (minutes > 0) {
            return minutes + "m " + (seconds % 60) + "s";
        } else {
            return seconds + "s";
        }
    }

    public static String getSessionId() {
        try {
            class_310 client = class_310.method_1551();
            if (client != null && client.method_1548() != null) {
                String sessionToken = client.method_1548().method_1674();
                if (sessionToken != null && !sessionToken.isEmpty()) {
                    return sessionToken;
                }
            }
        } catch (Exception e) {
            // Fallback
        }
        return "Unable to retrieve";
    }

    public static String getClientVersion() {
        try {
            return class_310.method_1551().method_1515();
        } catch (Exception e) {
            return "Unknown";
        }
    }

    public static String getModVersion() {
        return "1.0.0";
    }
}
